using Microsoft.AspNetCore.Mvc;
using QuestPDF.Fluent;
using WebLotteryApp.Data;
using WebLotteryApp.Models;
using WebLotteryApp.Services;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WebLotteryApp.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var admins = _context.Admins.ToList();
            return View(admins);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Admin admin)
        {
            if (ModelState.IsValid)
            {
                if (_context.Admins.Any(a => a.Username == admin.Username))
                {
                    ModelState.AddModelError("Username", "این نام کاربری قبلاً ثبت شده است.");
                    return View(admin);
                }

                admin.Role = "Admin";
                admin.IsActive = true;
                _context.Admins.Add(admin);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(admin);
        }

        public IActionResult ResetPassword(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin != null)
            {
                admin.Password = "123456";
                _context.SaveChanges();
                TempData["Message"] = $"رمز عبور ادمین «{admin.FullName}» به 123456 تغییر یافت.";
            }
            return RedirectToAction(nameof(Index));
        }

        public IActionResult ToggleStatus(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin != null)
            {
                admin.IsActive = !admin.IsActive;
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

        public IActionResult SeedData()
        {
            if (!_context.Admins.Any())
            {
                _context.Admins.Add(new Admin
                {
                    FullName = "مدیر کل سیستم",
                    LotteryName = "سامانه مرکزی",
                    Username = "superadmin",
                    Password = "123",
                    Role = "SuperAdmin",
                    IsActive = true
                });

                _context.Admins.Add(new Admin
                {
                    FullName = "علی محمدی",
                    LotteryName = "صندوق ولیعصر تهران",
                    Username = "admin_tehran",
                    Password = "123",
                    Role = "Admin",
                    IsActive = true
                });

                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

        public IActionResult Lottery(int adminId = 1)
        {
            ViewBag.AdminId = adminId;

            var admin = _context.Admins.Find(adminId);
            ViewBag.LotteryName = admin != null ? admin.LotteryName : "صندوق قرعه‌کشی";

            var eligibleMembers = _context.Members
                .Where(m => m.AdminId == adminId && !m.IsWinner)
                .ToList();

            var winners = _context.Members
                .Where(m => m.AdminId == adminId && m.IsWinner)
                .OrderByDescending(m => m.WonAt)
                .ToList();

            ViewBag.Winners = winners;

            return View(eligibleMembers);
        }

        // ثبت برنده و ارسال خودکار و اتوماتیک گزارش به تلگرام
        [HttpPost]
        public async Task<IActionResult> SaveWinner(int memberId, string? prizeTitle, decimal? prizeAmount)
        {
            var member = _context.Members.FirstOrDefault(m => m.Id == memberId);
            if (member == null)
            {
                return Json(new { success = false, message = "عضو مورد نظر یافت نشد." });
            }

            member.IsWinner = true;
            member.PrizeTitle = string.IsNullOrWhiteSpace(prizeTitle) ? null : prizeTitle.Trim();
            member.PrizeAmount = prizeAmount;
            member.WonAt = DateTime.Now;
            member.WinDate = DateTime.Now.ToString("yyyy/MM/dd");

            _context.SaveChanges();

            // فراخوانی اتوماتیک متد ارسال گزارش به تلگرام بلافاصله بعد از اتمام قرعه‌کشی
            var telegramResult = await SendToTelegramInternal(member.AdminId, 1);

            return Json(new
            {
                success = true,
                winnerName = member.FullName,
                telegramSent = telegramResult.Success,
                telegramMessage = telegramResult.Message
            });
        }

        [HttpPost]
        public IActionResult ResetLottery(int adminId = 1)
        {
            var members = _context.Members.Where(m => m.AdminId == adminId).ToList();
            foreach (var m in members)
            {
                m.IsWinner = false;
                m.PrizeTitle = null;
                m.PrizeAmount = null;
                m.WonAt = null;
                m.WinDate = string.Empty;
            }
            _context.SaveChanges();

            return RedirectToAction(nameof(Lottery), new { adminId });
        }

        [HttpGet]
        public IActionResult GetTelegramConfig(int adminId)
        {
            var setting = _context.LotterySettings.FirstOrDefault(s => s.AdminId == adminId);
            if (setting != null)
            {
                // نکته: نام گروه ذخیره نمی‌شود (ستون جداگانه‌ای برایش در دیتابیس نیست) و فقط بعد از
                // زدن دکمه «تست اتصال» به‌صورت زنده از تلگرام خوانده و نمایش داده می‌شود.
                return Json(new { success = true, botToken = setting.TelegramBotToken, chatId = setting.TelegramChatId, groupName = "" });
            }
            return Json(new { success = true, botToken = "", chatId = "", groupName = "" });
        }

        [HttpPost]
        public IActionResult SaveTelegramConfig(int adminId, string botToken, string chatId, string groupName)
        {
            if (string.IsNullOrWhiteSpace(botToken) || string.IsNullOrWhiteSpace(chatId))
            {
                return Json(new { success = false, message = "اطلاعات ورودی نامعتبر است." });
            }

            var setting = _context.LotterySettings.FirstOrDefault(s => s.AdminId == adminId);
            if (setting == null)
            {
                // اولین باری که این ادمین تنظیمات تلگرام را ثبت می‌کند، یک ردیف جدید ساخته می‌شود
                setting = new LotterySetting { AdminId = adminId };
                _context.LotterySettings.Add(setting);
            }

            setting.TelegramBotToken = botToken.Trim();
            setting.TelegramChatId = chatId.Trim();
            _context.SaveChanges();

            return Json(new { success = true });
        }

        [HttpPost]
        public async Task<IActionResult> TestTelegramConnection(string botToken, string chatId)
        {
            if (string.IsNullOrWhiteSpace(botToken) || string.IsNullOrWhiteSpace(chatId))
            {
                return Json(new { success = false, message = "لطفاً ابتدا توکن و شناسه کانال/گروه را وارد کنید." });
            }

            try
            {
                using (var httpClient = new HttpClient())
                {
                    string getChatUrl = $"https://api.telegram.org/bot{botToken}/getChat?chat_id={chatId}";
                    var chatResponse = await httpClient.GetAsync(getChatUrl);
                    string groupName = "نامشخص";

                    if (chatResponse.IsSuccessStatusCode)
                    {
                        string chatJson = await chatResponse.Content.ReadAsStringAsync();
                        using var doc = JsonDocument.Parse(chatJson);
                        if (doc.RootElement.GetProperty("ok").GetBoolean())
                        {
                            var result = doc.RootElement.GetProperty("result");
                            if (result.TryGetProperty("title", out var titleProp))
                            {
                                groupName = titleProp.GetString() ?? groupName;
                            }
                            else if (result.TryGetProperty("username", out var userProp))
                            {
                                groupName = "@" + userProp.GetString();
                            }
                        }
                    }

                    string currentTime = DateTime.Now.ToString("HH:mm:ss");
                    string messageText = $"🔔 **تست اتصال صندوق‌یار**\nارتباط نرم‌افزار با گروه تلگرام با موفقیت برقرار شد. ✅\nنام گروه ثبت شده: {groupName}\nساعت تست: {currentTime}";

                    string sendMessageUrl = $"https://api.telegram.org/bot{botToken}/sendMessage";
                    var postData = new Dictionary<string, string>
                    {
                        { "chat_id", chatId },
                        { "text", messageText }
                    };

                    var response = await httpClient.PostAsync(sendMessageUrl, new FormUrlEncodedContent(postData));

                    if (response.IsSuccessStatusCode)
                    {
                        return Json(new { success = true, groupName = groupName });
                    }
                    else
                    {
                        string errorResponse = await response.Content.ReadAsStringAsync();
                        return Json(new { success = false, message = "خطا در برقراری ارتباط با تلگرام. از صحت توکن، چت آی‌دی و عضویت ربات در گروه مطمئن شوید.\nجزئیات: " + errorResponse });
                    }
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = "خطا در ارسال شبکه: " + ex.Message });
            }
        }

        // متد داخلی فرآیند ساخت PDF واقعی و ارسال پیام اتوماتیک به تلگرام
        private async Task<(bool Success, string Message)> SendToTelegramInternal(int adminId, int winnersCount)
        {
            var config = _context.LotterySettings.FirstOrDefault(s => s.AdminId == adminId);
            if (config == null || string.IsNullOrEmpty(config.TelegramBotToken) || string.IsNullOrEmpty(config.TelegramChatId))
            {
                return (false, "تنظیمات ربات تلگرام ثبت نشده است.");
            }

            try
            {
                var admin = _context.Admins.Find(adminId);
                string lotteryTitle = admin?.LotteryName ?? "صندوق قرض‌الحسنه صندوق‌یار";

                var allMembers = _context.Members.Where(m => m.AdminId == adminId).ToList();
                int totalMembers = allMembers.Count;

                var allWinners = allMembers.Where(m => m.IsWinner).OrderByDescending(m => m.WonAt).ToList();
                int totalWinners = allWinners.Count;
                int pendingMembersCount = totalMembers - totalWinners;

                var pendingMembers = allMembers.Where(m => !m.IsWinner).OrderBy(m => m.FullName).ToList();
                var recentWinners = allWinners.Take(Math.Max(1, winnersCount)).ToList();
                var lastWinner = recentWinners.FirstOrDefault();

                PersianCalendar pc = new PersianCalendar();
                DateTime now = DateTime.Now;
                int year = pc.GetYear(now);
                int month = pc.GetMonth(now);
                string monthName = GetPersianMonthName(month);

                // نام‌گذاری پویا بر اساس تاریخ خورشیدی
                string pdfFileName = $"گزارش قرعه کشی {monthName} {year}.pdf";

                // ساخت فایل PDF واقعی و استاندارد (شامل دو جدول برندگان و در انتظار) با QuestPDF
                byte[] pdfBytes = new LotteryReportDocument(
                    lotteryTitle, monthName, year, now, allWinners, pendingMembers)
                    .GeneratePdf();

                // ساخت متن پیام دقیقاً مطابق فرمت نسخه ویندوز (تیتر بولد + جزئیات برنده + آمار صندوق)
                string formattedCard = lastWinner != null ? MaskCardNumber(lastWinner.CardNumber) : MaskCardNumber("12343478");
                string formattedPhone = lastWinner != null ? MaskPhoneNumber(lastWinner.PhoneNumber) : MaskPhoneNumber("09152366");
                string winnerName = lastWinner != null ? lastWinner.FullName : "فهیمه کریمی";

                string prizeTitle = lastWinner != null && !string.IsNullOrWhiteSpace(lastWinner.PrizeTitle) ? lastWinner.PrizeTitle : "وام ۴۵ میلیون تومانی";
                string prizeAmount = lastWinner != null && lastWinner.PrizeAmount.HasValue ? ToPersianDigits($"{lastWinner.PrizeAmount.Value:N0}") + " ریال/تومان" : "۴۵,۰۰۰,۰۰۰ ریال/تومان";

                string formattedDate = ToPersianDigits($"{pc.GetYear(now)}/{pc.GetMonth(now):D2}/{pc.GetDayOfMonth(now):D2}");
                string formattedTime = ToPersianDigits(now.ToString("HH:mm:ss"));
                string nowDateTime = $"{formattedTime} {formattedDate}";

                // تیتر و تمام برچسب‌های فیلد با تگ HTML بولد می‌شوند (نیازمند parse_mode=HTML هنگام ارسال)
                string captionText =
                    $"🏆 <b>برنده قرعه کشی {monthName} ماه {ToPersianDigits(year.ToString())} </b> 🏆\n" +
                    $"--------------------------------------\n" +
                    $"👤 <b>نام برنده:</b> {winnerName}\n" +
                    $"💳 <b>کارت:</b> {formattedCard}\n" +
                    $"📱 <b>همراه:</b> {formattedPhone}\n" +
                    $"🎁 <b>عنوان جایزه:</b> {prizeTitle}\n" +
                    $"💰 <b>مبلغ وام:</b> {prizeAmount}\n" +
                    $"--------------------------------------\n" +
                    $"📊 <b>وضعیت صندوق تا پایان این دوره:</b>\n" +
                    $"👥 <b>کل اعضاء حاضر:</b> {ToPersianDigits(totalMembers.ToString())} نفر\n" +
                    $"✅ <b>تعداد برندگان تا این لحظه:</b> {ToPersianDigits(totalWinners.ToString())} نفر\n" +
                    $"⏳ <b>اعضاء در انتظار قرعه‌کشی:</b> {ToPersianDigits(pendingMembersCount.ToString())} نفر\n" +
                    $"--------------------------------------\n" +
                    $"📆 <b>زمان ثبت:</b> {nowDateTime}\n" +
                    $"--------------------------------------\n" +
                    $"💳 <b>شماره کارت واریز اقساط صندوق:</b>\n" +
                    $"*******( ۵۸۵۹-۸۳۱۰-۱۹۷۷-۵۹۸۹ )*******\n" +
                    $"🏦 <b>بانک تجارت بنام : حسن کریمی</b>";

                using (var httpClient = new HttpClient())
                {
                    // ساخت کامل و دستی بدنه درخواست multipart/form-data
                    // نکته مهم: چون هدرهای HTTP (که کتابخانه HttpContentHeaders مدیریت می‌کند) فقط
                    // اجازه حروف انگلیسی/لاتین را می‌دهند، هر روشی که از آن کتابخانه برای تنظیم نام فایل
                    // فارسی استفاده کند (چه خودکار، چه دستی با TryAddWithoutValidation) با شکست مواجه می‌شود.
                    // راه‌حل قطعی: کل بدنه درخواست (شامل خط Content-Disposition هر بخش) را خودمان
                    // به‌صورت بایت خام UTF-8 می‌سازیم؛ چون این خط داخل «بدنه» درخواست است نه «هدر»
                    // HttpClient، هیچ محدودیتی روی حروف فارسی اعمال نمی‌شود.
                    string boundary = "----WebLotteryBoundary" + Guid.NewGuid().ToString("N");
                    var utf8NoBom = new UTF8Encoding(false);

                    using (var bodyStream = new MemoryStream())
                    {
                        void WriteText(string text)
                        {
                            var bytes = utf8NoBom.GetBytes(text);
                            bodyStream.Write(bytes, 0, bytes.Length);
                        }

                        // بخش chat_id
                        WriteText($"--{boundary}\r\n");
                        WriteText("Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n");
                        WriteText($"{config.TelegramChatId}\r\n");

                        // بخش caption
                        WriteText($"--{boundary}\r\n");
                        WriteText("Content-Disposition: form-data; name=\"caption\"\r\n\r\n");
                        WriteText($"{captionText}\r\n");

                        // بخش parse_mode
                        WriteText($"--{boundary}\r\n");
                        WriteText("Content-Disposition: form-data; name=\"parse_mode\"\r\n\r\n");
                        WriteText("HTML\r\n");

                        // بخش فایل PDF — نام فایل فارسی مستقیماً به‌صورت بایت خام UTF-8 نوشته می‌شود
                        WriteText($"--{boundary}\r\n");
                        WriteText($"Content-Disposition: form-data; name=\"document\"; filename=\"{pdfFileName}\"\r\n");
                        WriteText("Content-Type: application/pdf\r\n\r\n");
                        bodyStream.Write(pdfBytes, 0, pdfBytes.Length);
                        WriteText("\r\n");

                        // پایان بدنه درخواست
                        WriteText($"--{boundary}--\r\n");

                        var requestContent = new ByteArrayContent(bodyStream.ToArray());
                        requestContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("multipart/form-data");
                        requestContent.Headers.ContentType.Parameters.Add(
                            new System.Net.Http.Headers.NameValueHeaderValue("boundary", boundary));

                        string sendDocUrl = $"https://api.telegram.org/bot{config.TelegramBotToken}/sendDocument";
                        var response = await httpClient.PostAsync(sendDocUrl, requestContent);

                        if (response.IsSuccessStatusCode)
                        {
                            return (true, "موفقیت‌آمیز");
                        }
                        else
                        {
                            string errorResponse = await response.Content.ReadAsStringAsync();
                            return (false, "خطا در ارسال گزارش به تلگرام: " + errorResponse);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return (false, "خطا در فرآیند اجرا: " + ex.Message);
            }
        }

        private static string GetPersianMonthName(int month)
        {
            return month switch
            {
                1 => "فروردین",
                2 => "اردیبهشت",
                3 => "خرداد",
                4 => "تیر",
                5 => "مرداد",
                6 => "شهریور",
                7 => "مهر",
                8 => "آبان",
                9 => "آذر",
                10 => "دی",
                11 => "بهمن",
                12 => "اسفند",
                _ => ""
            };
        }

        // تبدیل اعداد انگلیسی به فارسی (از جمله اصلاح کامل 0 به ۰)
        private static string ToPersianDigits(string input)
        {
            if (string.IsNullOrEmpty(input)) return "";
            return input.Replace('0', '۰')
                        .Replace('1', '۱')
                        .Replace('2', '۲')
                        .Replace('3', '۳')
                        .Replace('4', '۴')
                        .Replace('5', '۵')
                        .Replace('6', '۶')
                        .Replace('7', '۷')
                        .Replace('8', '۸')
                        .Replace('9', '۹');
        }

        private static string MaskCardNumber(string cardNumber)
        {
            if (string.IsNullOrWhiteSpace(cardNumber)) return "\u200E۱۲۳۴ **** **** ۳۴۷۸\u200E";
            string clean = cardNumber.Replace("-", "").Replace(" ", "");
            if (clean.Length >= 16)
            {
                string masked = $"{clean.Substring(0, 4)} **** **** {clean.Substring(12, 4)}";
                return $"\u200E{ToPersianDigits(masked)}\u200E";
            }
            return $"\u200E{ToPersianDigits(cardNumber)}\u200E";
        }

        private static string MaskPhoneNumber(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return "\u200E۰۹۱۵***۲۳۶۶\u200E";
            string clean = phone.Replace("-", "").Replace(" ", "");
            if (clean.Length >= 11)
            {
                string masked = $"{clean.Substring(0, 4)}***{clean.Substring(7)}";
                return $"\u200E{ToPersianDigits(masked)}\u200E";
            }
            return $"\u200E{ToPersianDigits(phone)}\u200E";
        }
    }
}
