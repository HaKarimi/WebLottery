﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Mvc;
using System.IO;
using WebLotteryApp.Data;
using WebLotteryApp.Models;

namespace WebLotteryApp.Controllers
{
    public class MemberController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MemberController(ApplicationDbContext context)
        {
            _context = context;
        }

        // ۱. نمایش لیست اعضا
        public IActionResult Index(int adminId = 1)
        {
            ViewBag.AdminId = adminId;
            var members = _context.Members.Where(m => m.AdminId == adminId).ToList();
            return View(members);
        }

        // ۲. نمایش فرم ثبت عضو جدید
        public IActionResult Create(int adminId = 1)
        {
            var member = new Member { AdminId = adminId };
            return View(member);
        }

        // ۳. ذخیره عضو جدید با بررسی عدم تکراری بودن
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Member member)
        {
            ModelState.Remove("Admin");

            if (_context.Members.Any(m => m.PhoneNumber == member.PhoneNumber))
            {
                ModelState.AddModelError("PhoneNumber", "این شماره موبایل قبلاً ثبت شده است.");
            }

            if (_context.Members.Any(m => m.CardNumber == member.CardNumber))
            {
                ModelState.AddModelError("CardNumber", "این شماره کارت بانکی قبلاً ثبت شده است.");
            }

            if (ModelState.IsValid)
            {
                _context.Members.Add(member);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index), new { adminId = member.AdminId });
            }

            return View(member);
        }

        // ۴. نمایش فرم ویرایش عضو (GET)
        public IActionResult Edit(int id)
        {
            var member = _context.Members.Find(id);
            if (member == null)
            {
                return NotFound();
            }
            return View(member);
        }

        // ۵. ذخیره تغییرات ویرایش شده (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, string FullName, string PhoneNumber, string CardNumber)
        {
            var member = _context.Members.Find(id);
            if (member == null)
            {
                return NotFound();
            }

            if (_context.Members.Any(m => m.PhoneNumber == PhoneNumber && m.Id != id))
            {
                ModelState.AddModelError("PhoneNumber", "این شماره موبایل متعلق به عضو دیگری است.");
            }

            if (_context.Members.Any(m => m.CardNumber == CardNumber && m.Id != id))
            {
                ModelState.AddModelError("CardNumber", "این شماره کارت بانکی متعلق به عضو دیگری است.");
            }

            if (ModelState.IsValid)
            {
                member.FullName = FullName;
                member.PhoneNumber = PhoneNumber;
                member.CardNumber = CardNumber;

                _context.SaveChanges();
                return RedirectToAction(nameof(Index), new { adminId = member.AdminId });
            }

            return View(member);
        }

        // ۶. خروجی گرفتن اکسل از اعضا
        public IActionResult ExportToExcel(int adminId = 1)
        {
            var members = _context.Members.Where(m => m.AdminId == adminId).ToList();

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("اعضای صندوق");
                worksheet.RightToLeft = true;

                worksheet.Cell(1, 1).Value = "ردیف";
                worksheet.Cell(1, 2).Value = "نام و نام خانوادگی";
                worksheet.Cell(1, 3).Value = "شماره موبایل";
                worksheet.Cell(1, 4).Value = "شماره کارت بانکی";
                worksheet.Cell(1, 5).Value = "وضعیت برنده";

                var headerRow = worksheet.Row(1);
                headerRow.Style.Font.Bold = true;
                headerRow.Style.Fill.BackgroundColor = XLColor.FromHtml("#E2E8F0");

                for (int i = 0; i < members.Count; i++)
                {
                    var m = members[i];
                    int row = i + 2;

                    worksheet.Cell(row, 1).Value = i + 1;
                    worksheet.Cell(row, 2).Value = m.FullName;
                    worksheet.Cell(row, 3).Value = m.PhoneNumber;
                    worksheet.Cell(row, 4).Value = m.CardNumber;
                    worksheet.Cell(row, 5).Value = m.IsWinner ? $"برنده شده ({m.WinDate})" : "در صف انتظار";
                }

                worksheet.Columns().AdjustToContents();

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();
                    return File(
                        content,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        $"Members_List_{DateTime.Now:yyyyMMdd}.xlsx"
                    );
                }
            }
        }

        // ۷. نمایش صفحه آپلود فایل اکسل (GET)
        public IActionResult ImportFromExcel(int adminId = 1)
        {
            ViewBag.AdminId = adminId;
            return View();
        }

        // ۸. پردازش و آپلود فایل اکسل (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ImportFromExcel(IFormFile excelFile, int adminId = 1)
        {
            ViewBag.AdminId = adminId;

            if (excelFile == null || excelFile.Length == 0)
            {
                ViewBag.Error = "لطفاً یک فایل اکسل معتبر انتخاب کنید.";
                return View();
            }

            var newMembers = new List<Member>();
            int addedCount = 0;
            int skippedCount = 0;

            using (var stream = new MemoryStream())
            {
                await excelFile.CopyToAsync(stream);
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(1);
                    var rows = worksheet.RowsUsed().Skip(1); // رد کردن سطر هدر

                    foreach (var row in rows)
                    {
                        string fullName = row.Cell(1).GetValue<string>().Trim();
                        string phoneNumber = row.Cell(2).GetValue<string>().Trim();
                        string cardNumber = row.Cell(3).GetValue<string>().Trim();

                        // بررسی الزامی بودن هر سه فیلد
                        if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(cardNumber))
                        {
                            skippedCount++;
                            continue;
                        }

                        // بررسی عدم تکراری بودن شماره موبایل یا شماره کارت
                        bool existsInDb = _context.Members.Any(m => m.PhoneNumber == phoneNumber || m.CardNumber == cardNumber);
                        bool existsInList = newMembers.Any(m => m.PhoneNumber == phoneNumber || m.CardNumber == cardNumber);

                        if (!existsInDb && !existsInList)
                        {
                            newMembers.Add(new Member
                            {
                                FullName = fullName,
                                PhoneNumber = phoneNumber,
                                CardNumber = cardNumber,
                                AdminId = adminId
                            });
                            addedCount++;
                        }
                        else
                        {
                            skippedCount++;
                        }
                    }
                }
            }

            if (newMembers.Any())
            {
                _context.Members.AddRange(newMembers);
                await _context.SaveChangesAsync();
            }

            TempData["SuccessMessage"] = $"تعداد {addedCount} عضو با موفقیت اضافه شد." + (skippedCount > 0 ? $" ({skippedCount} مورد به دلیل نقص اطلاعات یا تکراری بودن نادیده گرفته شد)" : "");
            return RedirectToAction(nameof(Index), new { adminId });
        }

        // ۹. دانلود فایل نمونه اکسل برای اعضا
        public IActionResult DownloadSampleExcel()
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("نمونه اعضا");
                worksheet.RightToLeft = true;

                // عناوین ستون‌ها (Header)
                worksheet.Cell(1, 1).Value = "نام و نام خانوادگی";
                worksheet.Cell(1, 2).Value = "شماره موبایل";
                worksheet.Cell(1, 3).Value = "شماره کارت بانکی";

                var headerRow = worksheet.Row(1);
                headerRow.Style.Font.Bold = true;
                headerRow.Style.Fill.BackgroundColor = XLColor.FromHtml("#2563EB"); // آبی
                headerRow.Style.Font.FontColor = XLColor.White;

                // دیتای نمونه
                worksheet.Cell(2, 1).Value = "علی محمدی";
                worksheet.Cell(2, 2).Value = "09123456789";
                worksheet.Cell(2, 3).Value = "6037997512345678";

                worksheet.Columns().AdjustToContents();

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();
                    return File(
                        content,
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "Sample_Members.xlsx"
                    );
                }
            }
        }

        // ۱۰. حذف عضو
        public IActionResult Delete(int id)
        {
            var member = _context.Members.Find(id);
            if (member != null)
            {
                int adminId = member.AdminId;
                _context.Members.Remove(member);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index), new { adminId });
            }
            return RedirectToAction(nameof(Index));
        }
    }
}