﻿using Microsoft.AspNetCore.Mvc;
using WebLotteryApp.Data;
using WebLotteryApp.Models;
using System.Text.RegularExpressions;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace WebLotteryApp.Controllers
{
    public class UserPanelController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserPanelController(ApplicationDbContext context)
        {
            _context = context;

            // ثبت مجوز جامعه (رایگان) برای QuestPDF
            QuestPDF.Settings.License = LicenseType.Community;
        }

        // ۱. صفحه اصلی کاربر عادی
        public IActionResult Index(int adminId = 1)
        {
            ViewBag.AdminId = adminId;

            var allMembers = _context.Members.Where(m => m.AdminId == adminId).ToList();

            var winners = allMembers.Where(m => m.IsWinner).ToList();
            var pendingMembers = allMembers.Where(m => !m.IsWinner).ToList();

            // ماسک کردن اطلاعات برای نمایش عمومی
            foreach (var member in allMembers)
            {
                member.PhoneNumber = MaskPhoneNumber(member.PhoneNumber);
                member.CardNumber = MaskCardNumber(member.CardNumber);
            }

            ViewBag.Winners = winners;
            ViewBag.PendingMembers = pendingMembers;

            return View();
        }

        // ۲. فرم ثبت‌نام عضو جدید (GET)
        public IActionResult Register(int adminId = 1)
        {
            var member = new Member { AdminId = adminId };
            return View(member);
        }

        // ۳. ثبت‌نام عضو جدید (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(Member member)
        {
            ModelState.Remove("Admin");

            if (_context.Members.Any(m => m.PhoneNumber == member.PhoneNumber))
            {
                ModelState.AddModelError("PhoneNumber", "این شماره موبایل قبلاً ثبت شده است.");
            }

            if (_context.Members.Any(m => m.CardNumber == member.CardNumber))
            {
                ModelState.AddModelError("CardNumber", "این شماره کارت بانکی قبلاً ثبت شده است.");
            }

            if (ModelState.IsValid)
            {
                _context.Members.Add(member);
                _context.SaveChanges();
                TempData["SuccessMessage"] = "ثبت‌نام شما با موفقیت انجام شد.";
                return RedirectToAction(nameof(Index), new { adminId = member.AdminId });
            }

            return View(member);
        }

        // ۴. دانلود فایل PDF با چیدمان راست‌چین و ترتیب ستون‌های جدید
        public IActionResult ExportToPdf(int adminId = 1)
        {
            var members = _context.Members.Where(m => m.AdminId == adminId).ToList();

            var pdfBytes = Document.Create(container =>
            {
                container.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(30);
                    page.PageColor(Colors.White);
                    // تنظیم فونت فارسی بعنوان فونت پیش‌فرض
                    page.DefaultTextStyle(x => x.FontFamily("Vazirmatn").FontSize(9));

                    // --- هدر صفحه ---
                    page.Header().Column(col =>
                    {
                        col.Item().AlignCenter().Text("سامانه هوشمند مدیریت قرعه‌کشی صندوق‌یار").FontSize(14).SemiBold();
                        col.Item().PaddingTop(3).AlignCenter().Text("گزارش رسمی لیست عمومی اعضای صندوق").FontSize(10).FontColor(Colors.Grey.Darken1);

                        // تاریخ گزارش در سمت چپ
                        col.Item().PaddingTop(8).AlignLeft().Text(DateTime.Now.ToString("yyyy/MM/dd")).FontSize(9);

                        col.Item().PaddingTop(4).LineHorizontal(1).LineColor(Colors.Grey.Lighten1);
                    });

                    // --- محتوا و جدول ---
                    // فعال‌سازی راست‌چین برای کل محتوای اصلی
                    page.Content().PaddingTop(15).ContentFromRightToLeft().Table(table =>
                    {
                        // تعریف ۴ ستون با نسبتهای جدید (کاهش عرض ردیف)
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn(0.7f); // ردیف (باریک‌تر)
                            columns.RelativeColumn(3);    // نام و نام خانوادگی
                            columns.RelativeColumn(3);    // شماره همراه
                            columns.RelativeColumn(3.5f); // شماره کارت بانکی (کمی پهن‌تر)
                        });

                        // عناوین جدول (از راست به چپ)
                        table.Header(header =>
                        {
                            header.Cell().Element(CellStyle).Text("ردیف").Bold();
                            header.Cell().Element(CellStyle).Text("نام و نام خانوادگی").Bold();
                            header.Cell().Element(CellStyle).Text("شماره همراه").Bold();
                            header.Cell().Element(CellStyle).Text("شماره کارت بانکی").Bold();

                            static IContainer CellStyle(IContainer container)
                            {
                                return container
                                    .Background(Colors.Grey.Lighten3)
                                    .Border(1)
                                    .BorderColor(Colors.Grey.Lighten1)
                                    .Padding(6)
                                    .AlignCenter()
                                    .AlignMiddle();
                            }
                        });

                        // سطرهای اعضا (با چیدمان راست‌چین)
                        int index = 1;
                        foreach (var m in members)
                        {
                            // ردیف
                            table.Cell().Element(BodyCellStyle).Text(index.ToString());

                            // نام و نام خانوادگی
                            table.Cell().Element(BodyCellStyle).Text(m.FullName);

                            // شماره همراه (با حفظ حالت LTR برای شماره)
                            table.Cell().Element(BodyCellStyle).Text(text =>
                            {
                                text.Span(MaskPhoneNumber(m.PhoneNumber)).DirectionFromLeftToRight();
                            });

                            // شماره کارت بانکی (با حفظ حالت LTR برای شماره)
                            table.Cell().Element(BodyCellStyle).Text(text =>
                            {
                                text.Span(MaskCardNumber(m.CardNumber)).DirectionFromLeftToRight();
                            });

                            index++;
                        }

                        static IContainer BodyCellStyle(IContainer container)
                        {
                            return container
                                .Border(1)
                                .BorderColor(Colors.Grey.Lighten2)
                                .Padding(5)
                                .AlignCenter()
                                .AlignMiddle();
                        }
                    });

                    // --- فوتر صفحه ---
                    page.Footer().AlignCenter().Text(x =>
                    {
                        x.Span("صفحه ");
                        x.CurrentPageNumber();
                        x.Span(" از ");
                        x.TotalPages();
                    });
                });
            }).GeneratePdf();

            return File(pdfBytes, "application/pdf", $"Public_List_{DateTime.Now:yyyyMMdd}.pdf");
        }

        private string MaskPhoneNumber(string phone)
        {
            if (string.IsNullOrEmpty(phone) || phone.Length < 11) return phone;
            return $"{phone.Substring(0, 4)}****{phone.Substring(7)}";
        }

        private string MaskCardNumber(string card)
        {
            if (string.IsNullOrEmpty(card) || card.Length < 16) return card;
            return $"{card.Substring(0, 4)}********{card.Substring(12)}";
        }
    }
}