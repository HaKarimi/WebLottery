﻿using Microsoft.EntityFrameworkCore;
using WebLotteryApp.Models;

namespace WebLotteryApp.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        // جدول ادمین‌ها در دیتابیس
        public DbSet<Admin> Admins { get; set; }

        // جدول اعضای صندوق در دیتابیس
        public DbSet<Member> Members { get; set; }

        // جدول تنظیمات قرعه‌کشی در دیتابیس
        public DbSet<LotterySetting> LotterySettings { get; set; }
    }
}