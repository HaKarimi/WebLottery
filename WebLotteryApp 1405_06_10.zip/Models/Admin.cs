﻿namespace WebLotteryApp.Models
{
    public class Admin
    {
        // شناسه اختصاصی هر ادمین در دیتابیس
        public int Id { get; set; }

        // نام و نام خانوادگی ادمین
        public string FullName { get; set; } = string.Empty;

        // نام صندوق (مثلاً: صندوق ولیعصر تهران)
        public string LotteryName { get; set; } = string.Empty;

        // نام کاربری برای ورود
        public string Username { get; set; } = string.Empty;

        // رمز عبور
        public string Password { get; set; } = string.Empty;

        // نقش کاربر: SuperAdmin یا Admin
        public string Role { get; set; } = "Admin";

        // وضعیت اکانت: true برای فعال، false برای مسدود/غیرفعال
        public bool IsActive { get; set; } = true;

        // فیلدهای مربوط به تنظیمات تلگرام (جدید)
        public string? TelegramBotToken { get; set; }
        public string? TelegramChatId { get; set; }
    }
}