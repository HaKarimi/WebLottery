﻿using System.ComponentModel.DataAnnotations;

namespace WebLotteryApp.Models
{
    public class LotterySetting
    {
        // شناسه اختصاصی تنظیمات
        public int Id { get; set; }

        // شناسه ادمینی که این تنظیمات متعلق به صندوق اوست
        public int AdminId { get; set; }

        // عنوان جایزه (مثلاً: وام قرعه‌کشی خانوادگی)
        [Required(ErrorMessage = "عنوان جایزه الزامی است.")]
        public string PrizeTitle { get; set; } = "جایزه قرعه‌کشی ماهانه";

        // مبلغ جایزه (به تومان)
        [Range(0, long.MaxValue, ErrorMessage = "مبلغ جایزه نامعتبر است.")]
        public decimal PrizeAmount { get; set; } = 0;

        // تعداد برندگان در هر دوره قرعه‌کشی
        [Range(1, 100, ErrorMessage = "تعداد برندگان باید حداقل ۱ نفر باشد.")]
        public int WinnersCount { get; set; } = 1;

        // توکن ربات تلگرام (برای ارسال خودکار گزارش به گروه)
        public string TelegramBotToken { get; set; } = string.Empty;

        // شناسه گروه یا چت تلگرام (Chat ID)
        public string TelegramChatId { get; set; } = string.Empty;
    }
}