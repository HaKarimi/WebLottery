﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebLotteryApp.Models
{
    public class Member
    {
        // شناسه اختصاصی هر عضو
        public int Id { get; set; }

        // شناسه ادمین/صندوقی که این عضو متعلق به آن است
        public int AdminId { get; set; }

        // نام و نام خانوادگی عضو: فقط حروف فارسی و فاصله مجاز است
        [Required(ErrorMessage = "نام و نام خانوادگی الزامی است.")]
        [RegularExpression(@"^[\u0600-\u06FF\s]+$", ErrorMessage = "نام و نام خانوادگی باید فقط به زبان فارسی وارد شود.")]
        public string FullName { get; set; } = string.Empty;

        // شماره موبایل: باید ۱۱ رقم باشد و با 09 شروع شود
        [Required(ErrorMessage = "شماره موبایل الزامی است.")]
        [RegularExpression(@"^09\d{9}$", ErrorMessage = "شماره موبایل باید ۱۱ رقم بوده و با 09 شروع شود.")]
        public string PhoneNumber { get; set; } = string.Empty;

        // شماره کارت بانکی: باید دقیقاً ۱۶ رقم باشد
        [Required(ErrorMessage = "شماره کارت الزامی است.")]
        [RegularExpression(@"^\d{16}$", ErrorMessage = "شماره کارت بانکی باید دقیقاً ۱۶ رقم باشد.")]
        public string CardNumber { get; set; } = string.Empty;

        // وضعیت برنده شدن: true یعنی برنده شده، false یعنی هنوز در صف انتظار است
        public bool IsWinner { get; set; } = false;

        // تاریخ یا دوره برنده شدن
        public string WinDate { get; set; } = string.Empty;

        // تعداد سهام یا حق قرعه‌کشی
        public int SharesCount { get; set; } = 1;

        // ==========================================
        // فیلدهای جدید جهت ذخیره اطلاعات جایزه برای گزارش‌گیری
        // ==========================================

        // عنوان جایزه (مثلاً: وام ۵۰ میلیونی)
        public string? PrizeTitle { get; set; }

        // مبلغ جایزه (به تومان)
        public decimal? PrizeAmount { get; set; }

        // تاریخ دقیق دقیق ثبت برنده شدن
        public DateTime? WonAt { get; set; }
    }
}