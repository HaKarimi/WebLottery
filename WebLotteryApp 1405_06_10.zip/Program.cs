using Microsoft.EntityFrameworkCore;
using QuestPDF.Drawing;
using QuestPDF.Infrastructure;
using WebLotteryApp.Data;

// ثبت لایسنس رایگان (Community) کتابخانه QuestPDF
// توجه: طبق قوانین QuestPDF، این لایسنس رایگان صرفاً برای شرکت‌ها/افراد
// با درآمد سالانه محدود مجاز است؛ قبل از استفاده تجاری شرایط را بررسی کنید.
QuestPDF.Settings.License = LicenseType.Community;

var builder = WebApplication.CreateBuilder(args);

// ۱. افزودن سرویس‌های کنترلر و ویو (MVC)
builder.Services.AddControllersWithViews();

// ۲. ثبت دیتابیس SQLite و اتصال آن به ApplicationDbContext
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlite("Data Source=WebLottery.db"));

var app = builder.Build();

// ۳. ثبت فونت فارسی Vazirmatn برای استفاده در گزارش‌های PDF (QuestPDF)
// هر دو فایل رگولار و بولد با یک نام خانواده فونت ثبت می‌شوند تا .Bold() به‌درستی کار کند
var fontsFolder = Path.Combine(AppContext.BaseDirectory, "Fonts");
var regularFontPath = Path.Combine(fontsFolder, "Vazirmatn-Regular.ttf");
var boldFontPath = Path.Combine(fontsFolder, "Vazirmatn-Bold.ttf");

if (File.Exists(regularFontPath) && File.Exists(boldFontPath))
{
    using (var regularStream = File.OpenRead(regularFontPath))
    {
        FontManager.RegisterFontWithCustomName("Vazirmatn", regularStream);
    }
    using (var boldStream = File.OpenRead(boldFontPath))
    {
        FontManager.RegisterFontWithCustomName("Vazirmatn", boldStream);
    }
}
else
{
    throw new FileNotFoundException(
        "فایل‌های فونت Vazirmatn پیدا نشدند. مطمئن شوید پوشه Fonts کنار فایل اجرایی برنامه کپی شده است.");
}

// ۵. ایجاد خودکار دیتابیس و جداول در صورت عدم وجود
using (var scope = app.Services.CreateScope())
{
    var dbContext = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    dbContext.Database.EnsureCreated();
}

// ۶. تنظیمات مسیردهی و فایل‌های استاتیک
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// ۷. مسیردهی پیش‌فرض برنامه (ورود به HomeController و اکشن Index)
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();