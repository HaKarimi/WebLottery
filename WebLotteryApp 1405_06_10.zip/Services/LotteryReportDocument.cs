﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using System.Globalization;
using WebLotteryApp.Models;

namespace WebLotteryApp.Services
{
    /// <summary>
    /// سند PDF گزارش قرعه‌کشی شامل دو جدول:
    /// ۱) لیست برندگان   ۲) لیست اعضای در انتظار قرعه‌کشی
    /// این کلاس جایگزین متد قدیمی و دستی BuildNativePdfDocument شده است.
    /// </summary>
    public class LotteryReportDocument : IDocument
    {
        private readonly string _lotteryTitle;
        private readonly string _monthName;
        private readonly int _year;
        private readonly DateTime _generatedAt;
        private readonly List<Member> _winners;
        private readonly List<Member> _pendingMembers;

        public LotteryReportDocument(
            string lotteryTitle,
            string monthName,
            int year,
            DateTime generatedAt,
            List<Member> winners,
            List<Member> pendingMembers)
        {
            _lotteryTitle = lotteryTitle;
            _monthName = monthName;
            _year = year;
            _generatedAt = generatedAt;
            _winners = winners;
            _pendingMembers = pendingMembers;
        }

        public DocumentMetadata GetMetadata() => DocumentMetadata.Default;

        public void Compose(IDocumentContainer container)
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(30);
                page.PageColor(Colors.White);

                // فونت پیش‌فرض کل سند: Vazirmatn (باید در Program.cs ثبت شده باشد)
                page.DefaultTextStyle(x => x.FontFamily("Vazirmatn").FontSize(11));

                // جهت کلی سند از راست به چپ (فارسی)
                page.ContentFromRightToLeft();

                page.Header().Element(ComposeHeader);
                page.Content().Element(ComposeContent);

                page.Footer().AlignCenter().Text(x =>
                {
                    x.DefaultTextStyle(y => y.FontSize(9).FontColor(Colors.Grey.Darken1));
                    x.Span("صفحه ");
                    x.CurrentPageNumber();
                    x.Span(" از ");
                    x.TotalPages();
                });
            });
        }

        private void ComposeHeader(IContainer container)
        {
            container.Column(col =>
            {
                col.Item().AlignCenter().Text($"گزارش رسمی و جامع وضعیت صندوق قرض‌الحسنه {_lotteryTitle}")
                    .FontSize(17).Bold().FontColor(Colors.Blue.Darken3);

                col.Item().PaddingTop(3).AlignCenter()
                    .Text($"گزارش دوره مربوط به {_monthName} ماه {ToPersianDigits(_year.ToString())}  |  تاریخ ثبت: {ToPersianDateTime(_generatedAt)}")
                    .FontSize(10).FontColor(Colors.Grey.Darken2);

                col.Item().PaddingTop(8).LineHorizontal(1).LineColor(Colors.Grey.Lighten1);
            });
        }

        private void ComposeContent(IContainer container)
        {
            container.PaddingTop(15).Column(col =>
            {
                col.Spacing(22);
                col.Item().Element(ComposeWinnersTable);
                col.Item().Element(ComposePendingTable);
            });
        }

        // ================== جدول اول: برندگان ==================
        private void ComposeWinnersTable(IContainer container)
        {
            container.Column(col =>
            {
                col.Item().Text("🏆  لیست برندگان خوش‌شانس صندوق")
                    .FontSize(13).Bold().FontColor(Colors.Amber.Darken3);

                col.Item().PaddingTop(6).Table(table =>
                {
                    table.ColumnsDefinition(c =>
                    {
                        c.ConstantColumn(30);    // ردیف
                        c.RelativeColumn(2.2f);  // نام برنده
                        c.RelativeColumn(2.3f);  // شماره کارت بانکی
                        c.RelativeColumn(1.8f);  // شماره همراه
                        c.RelativeColumn(2.2f);  // تاریخ و ساعت قرعه‌کشی
                    });

                    table.Header(header =>
                    {
                        header.Cell().Element(HeaderCell).Text("#");
                        header.Cell().Element(HeaderCell).Text("نام برنده");
                        header.Cell().Element(HeaderCell).Text("شماره کارت بانکی");
                        header.Cell().Element(HeaderCell).Text("شماره همراه");
                        header.Cell().Element(HeaderCell).Text("تاریخ و ساعت قرعه‌کشی");
                    });

                    if (_winners.Count == 0)
                    {
                        table.Cell().ColumnSpan(5).Element(EmptyRowCell)
                            .Text("هنوز برنده‌ای در این دوره ثبت نشده است.");
                    }
                    else
                    {
                        int i = 1;
                        foreach (var w in _winners)
                        {
                            var bg = i % 2 == 0 ? Colors.Grey.Lighten4 : Colors.White;

                            table.Cell().Element(c => BodyCell(c, bg)).Text(ToPersianDigits(i.ToString()));
                            table.Cell().Element(c => BodyCell(c, bg)).Text(w.FullName);
                            table.Cell().Element(c => BodyCell(c, bg)).ContentFromLeftToRight().Text(MaskCardNumber(w.CardNumber));
                            table.Cell().Element(c => BodyCell(c, bg)).ContentFromLeftToRight().Text(MaskPhoneNumber(w.PhoneNumber));
                            table.Cell().Element(c => BodyCell(c, bg)).Text(ToPersianDateTime(w.WonAt));
                            i++;
                        }
                    }
                });
            });
        }

        // ================== جدول دوم: در انتظار قرعه‌کشی ==================
        private void ComposePendingTable(IContainer container)
        {
            container.Column(col =>
            {
                col.Item().Text("⏳  لیست اعضای محترم در انتظار قرعه‌کشی (ترتیب حروف الفبا)")
                    .FontSize(13).Bold().FontColor(Colors.Blue.Darken2);

                col.Item().PaddingTop(6).Table(table =>
                {
                    table.ColumnsDefinition(c =>
                    {
                        c.ConstantColumn(30);    // ردیف
                        c.RelativeColumn(2.2f);  // نام و نام خانوادگی
                        c.RelativeColumn(2.3f);  // شماره کارت بانکی
                        c.RelativeColumn(1.8f);  // شماره همراه
                        c.RelativeColumn(2.2f);  // وضعیت ثبت نهایی
                    });

                    table.Header(header =>
                    {
                        header.Cell().Element(HeaderCell).Text("#");
                        header.Cell().Element(HeaderCell).Text("نام و نام خانوادگی");
                        header.Cell().Element(HeaderCell).Text("شماره کارت بانکی");
                        header.Cell().Element(HeaderCell).Text("شماره همراه");
                        header.Cell().Element(HeaderCell).Text("وضعیت ثبت نهایی");
                    });

                    if (_pendingMembers.Count == 0)
                    {
                        table.Cell().ColumnSpan(5).Element(EmptyRowCell)
                            .Text("تمامی اعضا تاکنون برنده شده‌اند.");
                    }
                    else
                    {
                        int i = 1;
                        foreach (var m in _pendingMembers)
                        {
                            var bg = i % 2 == 0 ? Colors.Grey.Lighten4 : Colors.White;

                            table.Cell().Element(c => BodyCell(c, bg)).Text(ToPersianDigits(i.ToString()));
                            table.Cell().Element(c => BodyCell(c, bg)).Text(m.FullName);
                            table.Cell().Element(c => BodyCell(c, bg)).ContentFromLeftToRight().Text(MaskCardNumber(m.CardNumber));
                            table.Cell().Element(c => BodyCell(c, bg)).ContentFromLeftToRight().Text(MaskPhoneNumber(m.PhoneNumber));
                            table.Cell().Element(c => BodyCell(c, bg)).Text("(در صف قرعه‌کشی‌های آتی)");
                            i++;
                        }
                    }
                });
            });
        }

        // ================== استایل‌های کمکی جدول ==================
        private static IContainer HeaderCell(IContainer container) =>
            container
                .Background(Colors.Blue.Darken2)
                .Padding(6)
                .AlignCenter()
                .DefaultTextStyle(x => x.FontColor(Colors.White).Bold().FontSize(10));

        private static IContainer BodyCell(IContainer container, string backgroundColor) =>
            container
                .Background(backgroundColor)
                .BorderBottom(1)
                .BorderColor(Colors.Grey.Lighten2)
                .Padding(6)
                .AlignCenter()
                .DefaultTextStyle(x => x.FontSize(10));

        private static IContainer EmptyRowCell(IContainer container) =>
            container
                .Padding(12)
                .AlignCenter()
                .DefaultTextStyle(x => x.FontColor(Colors.Grey.Darken1).Italic().FontSize(10));

        // تبدیل اعداد انگلیسی به فارسی
        private static string ToPersianDigits(string input)
        {
            if (string.IsNullOrEmpty(input)) return "";
            return input.Replace('0', '۰').Replace('1', '۱').Replace('2', '۲').Replace('3', '۳')
                        .Replace('4', '۴').Replace('5', '۵').Replace('6', '۶').Replace('7', '۷')
                        .Replace('8', '۸').Replace('9', '۹');
        }

        // تبدیل تاریخ و ساعت میلادی به تاریخ و ساعت شمسی با اعداد فارسی
        private static string ToPersianDateTime(DateTime? dateTime)
        {
            if (!dateTime.HasValue) return "-";
            var pc = new PersianCalendar();
            var dt = dateTime.Value;
            string datePart = $"{pc.GetYear(dt)}/{pc.GetMonth(dt):D2}/{pc.GetDayOfMonth(dt):D2}";
            string timePart = dt.ToString("HH:mm:ss");
            return ToPersianDigits($"{datePart}  {timePart}");
        }

        // نمایش امن شماره کارت: فقط ۴ رقم اول و ۴ رقم آخر
        // نکته: این سلول‌ها با ContentFromLeftToRight() چپ‌به‌راست شده‌اند تا ترتیب گروه‌های عددی
        // (که ماهیتاً چپ‌به‌راست هستند) درست نمایش داده شود و برعکس نشود.
        private static string MaskCardNumber(string cardNumber)
        {
            if (string.IsNullOrWhiteSpace(cardNumber)) return "-";
            string clean = cardNumber.Replace("-", "").Replace(" ", "");
            if (clean.Length >= 16)
            {
                string masked = $"{clean.Substring(0, 4)} **** **** {clean.Substring(12, 4)}";
                return ToPersianDigits(masked);
            }
            return ToPersianDigits(cardNumber);
        }

        // نمایش امن شماره همراه: فقط ۴ رقم اول
        private static string MaskPhoneNumber(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return "-";
            string clean = phone.Replace("-", "").Replace(" ", "");
            if (clean.Length >= 11)
            {
                string masked = $"{clean.Substring(0, 4)}***{clean.Substring(7)}";
                return ToPersianDigits(masked);
            }
            return ToPersianDigits(phone);
        }
    }
}
